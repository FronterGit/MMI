---
name: New Feature
about: Creating a new feature for this project.
title: ''
labels: ''
assignees: ''

---

**Summary**

A quick intro or summary on the feature you want to create.

**Intended Outcome**

- What is the use case of this?
- How will it affect/benefit the project?

**How will it work?**

- How to use this feature?

*finally, please assign yourself to this issue if you intend to work on this new feature thanks!*
