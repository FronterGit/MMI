## [0.1.0]

### Bug Fixes

- Fixed Unity crash on exit bug.

## [0.0.1]

### New Features

- Experimental tflite integration of TTS inferencing using `fastspeech`.
- Sample folder for simple speech example. (only TTS)